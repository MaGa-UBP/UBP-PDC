package ar.edu.ubp.das.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import ar.edu.ubp.das.ws.CategoriaBean;
import ar.edu.ubp.das.ws.CategoriasWS;
import ar.edu.ubp.das.ws.CategoriasWSService;
import ar.edu.ubp.das.ws.Exception_Exception;

public class CritBusqVideosTagHandler extends SimpleTagSupport {

	private String onClick;
	
	@Override
	public void doTag() throws JspException, IOException {
		super.doTag();

		JspWriter out = this.getJspContext().getOut();
				  out.println("<fieldset>");	
		try {		
			CategoriasWSService service = new CategoriasWSService();
			CategoriasWS categorias = service.getCategoriasWSPort();

            out.println("<input type=\"text\" name=\"string_busqueda\" value=\"\" maxlength=\"255\" size=\"100\" /><br/><br/>");
            out.println("<input type=\"radio\" id=\"c0\" name=\"nro_categoria\" checked value=\"\"/><label for=\"c0\" checked>Todos</label>&nbsp;&nbsp;");
			for(CategoriaBean c : categorias.getCategorias()) {
            	out.println("<input type=\"radio\" id=\"c" + c.getNroCategoria() + "\" name=\"nro_categoria\" value=\"" + c.getNroCategoria() + "\"/><label for=\"c" + c.getNroCategoria() + "\">" + c.getNomCategoria() + "</label>&nbsp;&nbsp;");
			}
            out.println("<br/><br/><input type=\"button\" value=\"Buscar\" onclick=\"" + this.onClick + "\"/>");
        }
        catch(Exception_Exception ex) {
            out.println(ex.getMessage());
        }
        finally {
			out.println("</fieldset>");	
        }
	}
	
	public void setOnClick(String onClick) {
		this.onClick = onClick;
	}
	
}
