package ar.edu.ubp.das.bean;

public class CategoriaBean {

	private int nroCategoria;
	private String nomCategoria;
	
	public int getNroCategoria() {
		return nroCategoria;
	}
	
	public void setNroCategoria(int nroCategoria) {
		this.nroCategoria = nroCategoria;
	}
	
	public String getNomCategoria() {
		return nomCategoria;
	}
	
	public void setNomCategoria(String nomCategoria) {
		this.nomCategoria = nomCategoria;
	}
	
}

