package ar.edu.ubp.das.beans;

public class FeriadoBean 
{
	private String feriado;
	private String descripcion;
	public String getFeriado() {
		return feriado;
	}
	public void setFeriado(String feriado) {
		this.feriado = feriado;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
}
