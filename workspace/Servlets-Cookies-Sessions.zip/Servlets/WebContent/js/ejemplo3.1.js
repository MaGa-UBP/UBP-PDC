jQuery(document).ready(function() {
	$("#content").append("<p>LOAD Ejemplo 3.1</p>");	
});
