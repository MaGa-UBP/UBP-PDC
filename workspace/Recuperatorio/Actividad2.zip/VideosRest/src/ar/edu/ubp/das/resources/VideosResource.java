package ar.edu.ubp.das.resources;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.LinkedList;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import ar.edu.ubp.das.bean.CategoriaVideosBean;
import ar.edu.ubp.das.bean.VideoBean;

@Path("/videos")
@Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
public class VideosResource {
	
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response getVideos(@FormParam("nro_categoria") short nroCategoria, 
			                  @FormParam("string_busqueda") String stringBusqueda) {
        try {
        	Connection conn;
            PreparedStatement st;
            ResultSet result;

            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
            conn = DriverManager.getConnection("jdbc:sqlserver://localhost;databaseName=das", "sa", "pyxis");
            conn.setAutoCommit(true);

            try {
            	LinkedList<CategoriaVideosBean> categorias = new LinkedList<CategoriaVideosBean>();
            	LinkedList<VideoBean> videos;
            	CategoriaVideosBean categoria;
            	VideoBean video;
   
                st = conn.prepareStatement("select c.nom_categoria, " +
                                                  "v.nro_categoria, " +
                                                  "v.titulo, " +
	                                              "v.cantante, " +
	                                              "v.link_video, " +
	                                              "v.nro_video " +
                                            "from dbo.videos v (nolock) " +
                                                 "join dbo.categorias_videos c (nolock) " +
	                                               "on v.nro_categoria = c.nro_categoria " +
                                           "where (? is null " +
                                              "or  v.nro_categoria = ?) " +
                                             "and  v.titulo + ' ' + v.cantante + ' ' + v.titulo like '%' + isnull(ltrim(rtrim(?)), '') + '%' " +
                                           "order by c.nom_categoria, " +
                                                    "v.titulo;", ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);

                if(nroCategoria == 0) {
                	st.setNull(1, Types.TINYINT);
                	st.setNull(2, Types.TINYINT);
                }
                else {
                	st.setShort(1, nroCategoria);
                	st.setShort(2, nroCategoria);
                }
                st.setString(3, stringBusqueda);

                result = st.executeQuery();
            	result.next();
                while(result.getRow() > 0) {
                	categoria = new CategoriaVideosBean();
                	categoria.setNroCategoria(result.getShort("nro_categoria"));
                	categoria.setNomCategoria(result.getString("nom_categoria"));

                	videos = new LinkedList<VideoBean>();

                	nroCategoria = result.getShort("nro_categoria");
                	while(result.getRow() > 0 && nroCategoria == result.getShort("nro_categoria")) {
                    	video = new VideoBean();
                    	video.setNroVideo(result.getInt("nro_video"));
                    	video.setTitulo(result.getString("titulo"));
                    	video.setCantante(result.getString("cantante"));
                    	video.setLinkVideo(result.getString("link_video"));
                    	videos.add(video);
                		result.next();
                    }
                    categoria.setVideos(videos);
                    categorias.add(categoria);
                }
                st.close();

                return Response.status(Response.Status.OK).entity(categorias).build();
            }
    		catch(SQLException ex) {
				return Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
    		}
    		finally {
    			conn.close();
    		}
        }
        catch(InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException ex) {
			return Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
        }
	}

	@POST
	@Path("/sin_grupo")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response getVideosSinAgrupar(@FormParam("nro_categoria") short nroCategoria, 
			                            @FormParam("string_busqueda") String stringBusqueda) {
        try {
        	Connection conn;
            PreparedStatement st;
            ResultSet result;

            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
            conn = DriverManager.getConnection("jdbc:sqlserver://localhost;databaseName=das", "sa", "pyxis");
            conn.setAutoCommit(true);

            try {
            	LinkedList<VideoBean> videos = new LinkedList<VideoBean>();
            	VideoBean video;
   
                st = conn.prepareStatement("select c.nom_categoria, " +
                                                  "v.nro_categoria, " +
                                                  "v.titulo, " +
	                                              "v.cantante, " +
	                                              "v.link_video, " +
	                                              "v.nro_video " +
                                            "from dbo.videos v (nolock) " +
                                                 "join dbo.categorias_videos c (nolock) " +
	                                               "on v.nro_categoria = c.nro_categoria " +
                                           "where (? is null " +
                                              "or  v.nro_categoria = ?) " +
                                             "and  v.titulo + ' ' + v.cantante + ' ' + v.titulo like '%' + isnull(ltrim(rtrim(?)), '') + '%' " +
                                           "order by c.nom_categoria, " +
                                                    "v.titulo;");

                if(nroCategoria == 0) {
                	st.setNull(1, Types.TINYINT);
                	st.setNull(2, Types.TINYINT);
                }
                else {
                	st.setShort(1, nroCategoria);
                	st.setShort(2, nroCategoria);
                }
                st.setString(3, stringBusqueda);

                result = st.executeQuery();
            	while(result.next()) {
                	video = new VideoBean();
                	video.setNroCategoria(result.getShort("nro_categoria"));
                	video.setNomCategoria(result.getString("nom_categoria"));
                	video.setNroVideo(result.getInt("nro_video"));
                	video.setTitulo(result.getString("titulo"));
                	video.setCantante(result.getString("cantante"));
                	video.setLinkVideo(result.getString("link_video"));
                	videos.add(video);
                }
                st.close();

                return Response.status(Response.Status.OK).entity(videos).build();
            }
    		catch(SQLException ex) {
				return Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
    		}
    		finally {
    			conn.close();
    		}
        }
        catch(InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException ex) {
			return Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
        }
	}
	
}
