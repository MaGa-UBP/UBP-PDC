package ar.edu.ubp.das.bean;

public class PaisBean 
{
	private String codPais;
	private String nomPais;
	
	public String getCodPais()
	{
		return this.codPais;
	}
	public void setCodPais(String codPais)
	{
		this.codPais = codPais;
	}
	
	public String getNomPais()
	{
		return this.nomPais;
	}
	public void setNomPais(String nomPais)
	{
		this.nomPais = nomPais;
	}
}
