package ar.edu.ubp.das.beans;

public class A�oFeriadoBean 
{
	private String a�o;
	private String actual;
	
	public String getA�o() {
		return a�o;
	}
	public void setA�o(String a�o) {
		this.a�o = a�o;
	}
	public String getActual() {
		return actual;
	}
	public void setActual(String actual) {
		this.actual = actual;
	}
}
