package ar.edu.ubp.das.bean;

public class ProvinciaBean 
{
	private String codProvincia;
	private String nomProvincia;
	
	public String getCodProvincia()
	{
		return this.codProvincia;
	}
	public void setCodProvincia(String codProvincia)
	{
		this.codProvincia = codProvincia;
	}
	
	public String getNomProvincia()
	{
		return this.nomProvincia;
	}
	public void setNomProvincia(String nomProvincia)
	{
		this.nomProvincia = nomProvincia;
	}
}
