@javax.xml.bind.annotation.XmlSchema(namespace = "http://jaxb.dev.java.net/array")
package net.java.dev.jaxb.array;
