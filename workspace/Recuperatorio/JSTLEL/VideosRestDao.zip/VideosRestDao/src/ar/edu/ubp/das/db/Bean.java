package ar.edu.ubp.das.db;

public interface Bean {

}
